<template>
    <div class = "areaInfo">
        <ul style="padding: 0;">
            <li v-for="index in areaTitle[data].data" :key="index">
                <div class="areaTitle" @click="getData(index.title)">{{index.title}}</div>
                    <areaPhoneInfo :handleData="index.data.result" v-show="displayInfo==index.title"
                    ></areaPhoneInfo>
            </li>
        </ul>
    </div>
</template>
<script>
import {areaData} from '../data'
import areaPhoneInfo from './areaPhoneInfo.vue';
export default {
    name:'areaInfo',
    props:['titleName'],
    components:{
        areaPhoneInfo,
    },
    data(){
        return{
            data:null,
            areaTitle:areaData,
            displayInfo:null,
            show:false,
        }
    },
    created(){
        this.processData(this.titleName);
    },
    watch:{
        //进行数据更新，当titleName存在新的数据时，调用方法让响应式和newVal对应
        titleName(newVal){
            this.processData(newVal)
        }
    },
    methods: {
        processData(parentData)
        {
            this.data = parentData
        },
        getData(Element){
            if(this.displayInfo == Element){
                this.displayInfo=null
            }
            else{
                this.displayInfo = Element
            }
            // console.log(this.displayInfo)
        }
    },
}
</script>
<style>
    ul{
        list-style: none;
    }
    .areaTitle{
        width: 100%;
        height: 100%;
    }
    .areaTitle{
        width:90%;
        margin-top:0;
        padding-top:10px;
        padding-left:16px;
        font-size:17.6px;
        background:url(../assets/img/arr.png) no-repeat center right;
        background-size: 20px 20px;
    }
    .slide-enter-active, .slide-leave-active {
        transition: all 0.5s ease;
        overflow: hidden;
    }
    .slide-enter, .slide-leave-to {
        max-height: 0;
    }
</style>