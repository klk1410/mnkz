<template lang="">
    <div class="main">
        <div class="top">
            <a href="" class="returnButton"><img src="../assets/img/back.png"></a>
            <div class="title">各地配送中心电话</div>
        </div>
        <div class="menuButton1">
            <!-- areaTitle为menuButton传上来的参数 -->
            <menuButton @areaTitle="handleData"></menuButton>
        </div>
        <div class="pad">
            <p class="tip">如需配送请拨打当地配送电话，部分地区暂不支持配送，其他疑问，请致电客服。</p>
            <p class="areaTip">
            {{areaTitle}}配送中心电话
            </p> 
        </div>
        <areaInfo :titleName="areaIndex"></areaInfo>
        <a href="">
            <button class="backButton">返回</button>
        </a>
    </div>
</template>
<script>
//子组件：menuButton（生成按钮和传回目前按钮的数据）
import menuButton from "./menuButton.vue"
import areaInfo from "./areaInfo.vue"
export default {
    name:'mainPage',
    components:{
      menuButton,
      areaInfo,
    },
    data(){
      return{
        areaTitle :'南宁',
        areaIndex :'4',
      }
    },
    methods: {
      handleData(data){
        this.areaTitle = Object.values(data)[0];
        this.areaIndex = Object.keys(data)[0];
      }
    },
}

</script>
<style>
body{
  margin: 0;
  padding: 0;
  font-family: "微软雅黑";
}
.main {
  width:100%;
  height:100%;
}

.main .top{
    width: 100;
    height: 3rem;
    background-color: #f7f7f7;
    line-height: 3rem;
}
.main .top .title{
    text-align: center;
    font-size: 1.2rem;
}
.main .returnButton{
  float:left;
  margin-left:20px ;
  position: absolute;
  top: 8px;
}
.top .returnButton img{
  width: 30px;
  height: 30px;
  display: inline-block;
}
.menuButton1{
  width: 100%;
  height: 100%;
}
.backButton{
  height: 3rem;
  width: 100%;
  background-color: red;
  text-align: center;
  color:#fff;
  font-size: 1.3rem;
  position: fixed;
  bottom: 0;
  border: 0;
}
.pad{
  margin-top: 10px;
  width: 100%;
  height: 6rem;
  border-bottom: 2px solid #DDDDDD;
}
.tip{
  margin:20px 16px 16px;
  font-size: 0.9rem;
  line-height: 24px;
}
.pad .areaTip{
  margin: 0 16px;
  font-size: 1.3rem;
  color:red;
}
</style>